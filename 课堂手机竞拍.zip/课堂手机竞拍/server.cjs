const http=require('node:http'),fs=require('node:fs'),path=require('node:path'),os=require('node:os');
const {makeRoom,view,apply,Fault}=require('./cloud-function/engine.cjs');
const dir=path.join(__dirname,'data'),dbfile=path.join(dir,'rooms.json');fs.mkdirSync(dir,{recursive:true,mode:0o700});
let rooms=fs.existsSync(dbfile)?JSON.parse(fs.readFileSync(dbfile,'utf8')):{};
function save(){const tmp=dbfile+'.tmp';fs.writeFileSync(tmp,JSON.stringify(rooms),{mode:0o600});fs.renameSync(tmp,dbfile)}
const port=Number(process.env.AUCTION_PORT||8765),root=path.join(__dirname,'site');
const send=(res,status,value)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(value))};
const local=req=>['127.0.0.1','::1','::ffff:127.0.0.1'].includes(req.socket.remoteAddress);
const ips=()=>Object.values(os.networkInterfaces()).flat().filter(x=>x.family==='IPv4'&&!x.internal&&!x.address.startsWith('198.18.')).map(x=>x.address);
const server=http.createServer(async(req,res)=>{
 try{
 const url=new URL(req.url,'http://localhost');
 if(url.pathname==='/api'){
  if(req.method!=='POST')throw new Fault('请求方式无效。',405);
  if(req.headers.origin&&new URL(req.headers.origin).host!==req.headers.host)throw new Fault('请从课堂入口操作。',403);
  let body='';for await(const b of req){body+=b;if(body.length>6000)throw new Fault('请求过大。',413)}
  const input=JSON.parse(body);if(input.action==='create'){
   if(!local(req))throw new Fault('请教师在本机入口创建课堂。',403);
   let made;do{made=makeRoom()}while(rooms[made.room.id]);
   const previous=rooms;rooms={...rooms,[made.room.id]:made.room};try{save()}catch(e){rooms=previous;throw e}
   return send(res,200,{room:made.room.id,token:made.teacherToken,state:view(made.room,made.teacherToken),addresses:ips().map(ip=>`http://${ip}:${port}/auction.html?room=${made.room.id}`)});
  }
  if(input.action==='addresses'){if(!local(req))throw new Fault('仅教师本机查看。',403);return send(res,200,{addresses:ips().map(ip=>`http://${ip}:${port}/auction.html?room=${input.room}`)})}
  const old=rooms[String(input.room)];if(!old)throw new Fault('课堂号不正确。',404);
  const copy=JSON.parse(JSON.stringify(old)),result=apply(copy,input);
  if(input.action!=='state'){rooms[copy.id]=copy;try{save()}catch(e){rooms[copy.id]=old;throw e}}
  return send(res,200,result);
 }
 const name=url.pathname==='/'?'index.html':decodeURIComponent(url.pathname).slice(1),file=path.resolve(root,name);
 if(!file.startsWith(root+path.sep))throw new Fault('无效路径。',403);
 if(!fs.existsSync(file)||!fs.statSync(file).isFile())throw new Fault('页面不存在。',404);
 const ext=path.extname(file);res.writeHead(200,{'Content-Type':({'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.png':'image/png'})[ext]||'application/octet-stream','Cache-Control':'no-cache'});fs.createReadStream(file).pipe(res);
 }catch(e){send(res,e.status||500,{error:e instanceof Fault?e.message:e instanceof SyntaxError?'请求格式错误。':'保存或连接失败，请重试。'})}
});
server.listen(port,'0.0.0.0',()=>{console.log(`教师入口：http://localhost:${port}/auction.html?mode=teacher`);ips().forEach(ip=>console.log(`学生入口：http://${ip}:${port}/auction.html`));console.log('保持此窗口打开。成交记录自动保存在 data 文件夹。')});
server.on('error',e=>{console.error(e.code==='EADDRINUSE'?'竞拍服务已在运行，请打开教师入口。':e.message);process.exit(1)});
