#!/bin/zsh
cd "${0:A:h}"
TASK_NODE="/Users/alan/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node"
if [[ ! -x "$TASK_NODE" ]]; then TASK_NODE="$(command -v node)"; fi
if [[ -z "$TASK_NODE" || ! -x "$TASK_NODE" ]]; then
  echo "这台电脑没有运行环境。请在原制作电脑使用，或安装 Node.js 22 后重新打开。"
  read -k 1
  exit 1
fi
"$TASK_NODE" server.cjs &
TASK_SERVER_PID=$!
trap 'kill "$TASK_SERVER_PID" 2>/dev/null' EXIT INT TERM
sleep 1
open "http://localhost:8765/auction.html?mode=teacher"
wait "$TASK_SERVER_PID"
