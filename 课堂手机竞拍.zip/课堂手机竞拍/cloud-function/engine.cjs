const crypto=require('node:crypto');
const LOTS=['一辈子健康的身体','一张环球旅行的机票','三两个知心朋友','一项非常优秀的谋生技能','聪明才智','一座豪华别墅'];
class Fault extends Error{constructor(message,status=400){super(message);this.status=status}}
const hash=x=>crypto.createHash('sha256').update(String(x)).digest('hex');
const token=()=>crypto.randomBytes(24).toString('hex');
const equal=(a,b)=>typeof a==='string'&&typeof b==='string'&&a.length===b.length&&crypto.timingSafeEqual(Buffer.from(a),Buffer.from(b));
function makeRoom(){const teacherToken=token(),codes=Array.from({length:15},()=>crypto.randomBytes(4).toString('hex').slice(0,6).toUpperCase());return {teacherToken,room:{id:String(crypto.randomInt(100000,1000000)),teacherHash:hash(teacherToken),codes,codeHashes:codes.map(hash),members:Array(15).fill(null),balances:Array(15).fill(1000),lot:null,status:'waiting',high:null,records:[],bids:[],version:0,undo:null,applied:[],expires:Date.now()+48*3600000}}}
function role(r,key){if(equal(r.teacherHash,hash(key)))return {teacher:true};let i=r.members.findIndex(m=>m&&equal(m.hash,hash(key)));if(i<0)throw new Fault('参与凭证无效，请重新加入。',401);return {teacher:false,group:i}}
function view(r,key){let a=role(r,key);return {id:r.id,version:r.version,lots:LOTS,lot:r.lot,status:r.status,high:r.high,balances:r.balances,records:r.records,joined:r.members.map(Boolean),expires:r.expires,...(a.teacher?{teacher:true,codes:r.codes,bids:r.bids,canUndo:!!r.undo}:{teacher:false,group:a.group})}}
function apply(r,input){if(Date.now()>r.expires)throw new Fault('课堂已过期，请教师新建课堂。',410);const action=input.action;
 if(action==='join'){const i=Number(input.group);if(!Number.isInteger(i)||i<0||i>=15||!equal(r.codeHashes[i],hash(String(input.code||'').trim().toUpperCase())))throw new Fault('组号或分组码不正确。',401);if(r.members[i])throw new Fault('本组已有代表加入，请教师重置该组后再加入。',409);const k=input.newToken||token();r.members[i]={hash:hash(k)};r.version++;return {token:k,state:view(r,k)}}
 const a=role(r,input.token);if(action==='state')return {state:view(r,input.token)};
 if(typeof input.requestId!=='string'||!/^[a-f0-9-]{16,64}$/.test(input.requestId))throw new Fault('请求编号无效。');
 if(r.applied.includes(input.requestId))return {state:view(r,input.token),duplicate:true};
 if(action==='bid'){
  if(a.teacher)throw new Fault('请由小组代表提交报价。',403);
  if(r.status!=='open')throw new Fault('当前拍品已暂停或截止。',409);
  if(input.lot!==r.lot)throw new Fault('拍品已切换，请查看当前拍品。',409);
  const next=(r.high?.amount||0)+100;
  if(input.amount!==next)throw new Fault('价格已变化，请按最新价格重新出价。',409);
  if(r.high?.group===a.group)throw new Fault('本组已经是最高报价，无需再次出价。',409);
  if(next>r.balances[a.group])throw new Fault('本组余额不足，不能透支。',409);
  r.high={group:a.group,amount:next,time:Date.now()};r.bids.push({lot:r.lot,...r.high});r.bids=r.bids.slice(-100);
 }else{
  if(!a.teacher)throw new Fault('该操作仅限教师。',403);
  if(action==='open'){
   const i=Number(input.lot);if(!Number.isInteger(i)||i<0||i>=6)throw new Fault('请选择有效拍品。');
   if(r.records.some(x=>x.lot===i))throw new Fault('此拍品已成交或流拍。',409);
   if(r.status==='open'||r.status==='paused')throw new Fault('请先完成当前拍品，再开启下一项。',409);
   r.lot=i;r.status='open';r.high=null;r.undo=null;
  }else if(action==='pause'){
   if(r.status!=='open')throw new Fault('当前没有进行中的竞拍。',409);r.status='paused';
  }else if(action==='resume'){
   if(r.status!=='paused')throw new Fault('当前拍品不能继续竞拍。',409);r.status='open';
  }else if(action==='settle'){
   if(r.status!=='paused')throw new Fault('请先截止出价，再确认成交。',409);
   if(!r.high)throw new Fault('无人出价，可选择流拍。',409);
   if(r.records.some(x=>x.lot===r.lot))throw new Fault('这项已结束，不能重复成交。',409);
   if(r.high.amount>r.balances[r.high.group])throw new Fault('余额不足。',409);
   r.undo={balances:[...r.balances],records:r.records.map(x=>({...x})),lot:r.lot,high:{...r.high}};
   r.balances[r.high.group]-=r.high.amount;r.records.push({lot:r.lot,group:r.high.group,amount:r.high.amount,time:Date.now()});r.status='sold';
  }else if(action==='pass'){
   if(r.status!=='paused'||r.high)throw new Fault('请截止出价；有报价时不能流拍。',409);
   r.undo={balances:[...r.balances],records:r.records.map(x=>({...x})),lot:r.lot,high:null};r.records.push({lot:r.lot,group:null,amount:0,time:Date.now()});r.status='passed';
  }else if(action==='undo'){
   if(!r.undo||!['sold','passed'].includes(r.status))throw new Fault('仅可在开始下一拍品前撤销上一笔。',409);
   r.balances=r.undo.balances;r.records=r.undo.records;r.lot=r.undo.lot;r.high=r.undo.high;r.status='paused';r.undo=null;
  }else if(action==='resetGroup'){
   const i=Number(input.group);if(!Number.isInteger(i)||i<0||i>=15)throw new Fault('组号无效。');r.members[i]=null;r.codes[i]=crypto.randomBytes(4).toString('hex').slice(0,6).toUpperCase();r.codeHashes[i]=hash(r.codes[i]);
  }else throw new Fault('操作无效。');
 }
 r.version++;r.applied.push(input.requestId);r.applied=r.applied.slice(-100);return {state:view(r,input.token)};
}
module.exports={LOTS,Fault,hash,equal,token,makeRoom,apply,view};
